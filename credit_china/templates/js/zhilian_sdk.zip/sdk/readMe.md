# 智联招聘

## 文件目录
```
|- sdk
    |- decrypt.js   # 生成MmEwMD核心逻辑
    |- get_params.js  # 执行页面js，生成所需要的参数，解密逻辑需要
    |- server.js    # 开启获取加密url接口服务
    |- zhilian_demo.py  # python代码使用示例
    |- readMe.md    # 说明文件
```

## sdk使用说明
1. 运行server.js，开启获取后缀接口，
   接口：http://host:8090/get_url, post请求，代码示例：
   ```python
   import requests
    
   # api接口
   url = "http://localhost:8090/get_url"
   # post请求体
   body = {
        "innerCode": inner_code,   # 页面返回的js代码
        "meta": meta,  # 页面返回的meta值
        "url": old_url     # 搜索请求的url
   }
   # 请求获取后缀
   response = requests.post(url, data=body)
   # 响应内容即是所需要的带参数的url
   new_url = response.text
   # https://fe-api.zhaopin.com:443/c/i/sou?_v=0.09742947&x-zp-page-request-id=c589ef9e0b9c440cb0e6c9b92f98bf53-1598404891.4859705138072.03869055994&x-zp-client-id=833acd0e-2092-41d1-8d51-b0d8d5e1e7be&MmEwMD=5UC9xLnirwRtXxztz6spw7xb86YhqZhFhe_QcJpLCX.0xbgHHbhRZsgTU6M.Z1n8Czi4PcP0Dv4.g7Y1vtNC5nNHrf0VjIEq_O55Sr627IkmqbV6nixUvo0_aC5JKUHXU0O8CfqmVLRvvNaqlmSlcixPMIgqeRM2yYVFcRXRftTxpETtRmr_DDg6PmeLFIP6N0wIXMFF8WKFzWnmyYwf47nAI6qtQsHZw4OPl6fARS5z2g6cNn.WDs5dlov4gdftytJNf.IS9MbQn13RQ3JIGYIzV6El_H8u3TpuJAd7KYfq4uV8ruyXyX9JE1dNQpuRvPnU30Z.pSAeXRAzUHoyYs9Ga_8cTEbFZZQQvIXZlj4viBAndUlF4rMHL4He7wv8GH7c.5jBxGz9FG_xOeZbzkx.CvhZqiIThULGuHf4w7qSLaG
   ```
