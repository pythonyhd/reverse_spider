var express = require("express");
var paramFunc = require("./get_params.js");
var cookieFunc = require("./decrypt.js");

var bodyParser = require('body-parser');
var api = express();

api.use(bodyParser.urlencoded({
    parameterLimit: 50000,
    limit: '50mb',
    extended: false
}));

// api.get('/get_params', function (req, res) {
//     var token = sdk.jeeq();
//     res.send(token)
// });

api.post('/get_url', function (req, res) {
    var innerCode = req.body.innerCode;
    var meta = req.body.meta;
    var url = req.body.url;

    console.log(innerCode);
    var params = paramFunc.getParams(innerCode);
    console.log(params);

    var new_url = cookieFunc.getUrl(meta, url, params);
    console.log(new_url);

    res.send(new_url)
});


var server = api.listen(8090, function () {});