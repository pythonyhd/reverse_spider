# encoding: utf-8
# Author   : allen
# @Time    : 2020/8/19 下午2:14
# @File    : zhilian_demo.py.py
# @Software: PyCharm
# @Desc    :
import random
import re
import time

import requests

from lxml import etree

session = requests.session()

headers = {
    'Host': 'sou.zhaopin.com',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.70 Safari/537.36',
    'sec-fetch-user': '?1',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8',
}

session.headers = headers


def pre_request():
    url = "https://sou.zhaopin.com/?jl=530&sf=0&st=0&kw=%E5%9B%BD%E7%A0%94%E5%A4%A7%E6%95%B0%E6%8D%AE%E7%A0%94%E7%A9%B6%E9%99%A2&kt=3"
    response = session.get(url)
    print(response)
    print(response.text)


def first_request():
    url = "https://sou.zhaopin.com/?jl=530&sf=0&st=0&kw=%E5%9B%BD%E7%A0%94%E5%A4%A7%E6%95%B0%E6%8D%AE%E7%A0%94%E7%A9%B6%E9%99%A2&kt=3"

    payload = {}

    response = session.get(url)
    print("====================first request: =============================")
    print(response)
    print(response.headers)
    print(session.cookies)

    # 获取响应的x-zp-page-request-id和x-zp-client-id
    client_id = response.cookies.get("x-zp-client-id")
    request_id1 = re.search(r'zpPageRequestId = "(.*?)"', response.text, flags=re.DOTALL).group(1)
    request_id = request_id1 + str(time.time()) + str(random.random() * 1000000)
    request_params = {
        "request_id": request_id,
        "client_id": client_id
    }

    # print(response.text)
    html = etree.HTML(response.text)
    jscode = html.xpath(r'//script[@r="m"]/text()')[0]
    meta = html.xpath(r'//meta[starts-with(@content, "{")]/@content')[0]
    return jscode, meta, request_params


def get_url(inner_code, meta, old_url):
    url = "http://localhost:8090/get_url"
    body = {
        "innerCode": inner_code,
        "meta": meta,
        "url": old_url
    }
    response = requests.post(url, data=body)
    new_url = response.text
    return new_url


def real_request(inner_code, meta, request_params):
    print("==========================real request: ======================")
    _v = str(random.random())[:10]
    request_id = request_params["request_id"]
    client_id = request_params["client_id"]
    url = "https://fe-api.zhaopin.com/c/i/sou?_v={}&x-zp-page-request-id={}&x-zp-client-id={}".format(_v, request_id,
                                                                                                      client_id)
    print(url)

    new_url = get_url(inner_code, meta, url)

    new_url = new_url.replace("https://fe-api.zhaopin.com:443", "https://fe-api.zhaopin.com")

    payload = "{\"pageSize\":\"90\",\"cityId\":\"530\",\"workExperience\":\"-1\",\"companyType\":\"-1\",\"employmentType\":\"-1\",\"jobWelfareTag\":\"-1\",\"kw\":\"国研大数据研究院\",\"kt\":\"3\"}".encode()

    print(new_url)
    headers = {
        # "authority": "fe-api.zhaopin.com",
        # "method": "POST",
        # "path": "/c/i/sou?_v=0.21592636&x-zp-page-request-id=6aca2680280647c4b1069c0e0d479e11-1598344449065-558298&x-zp-client-id=d346d8f0-3b6b-408a-8c9e-7733c3971936&MmEwMD=56qSbrl5XzXnIlk8ajeIOG6s0Foepnmr7BOxcpD1oqV5jF3pjJtvq_fJQZOlEeVC3OAq5_CRqzM3.71i_WVL6X.5Kquu987YsQkxb2LTrrAqNsACnJSLEnV0v7bMGs1LoUiPAgJKzP1F2atOrCgS7WwOgAiTjC4FgOLtgZCoUv2dzeTRf4H_M.NLmcFD67iLSWh5u6l82KIzhaxAFiw4zLq4oWcNJCeKlgWp89f64M6PH4Muy0SCPFCGMBxhgsbbfYdT_OJf79SB3e0.obgtG_33TY8guw2DQjQCP.laUNg3asMi4ET1sRA7P.0lrUil5tu9Eex4L5_SdqMEU6Gx5PHdXWA3hB8e4OlbKtB6F2H7RYeWfkqyP4vpuwXUl4MEvlxI",
        # "scheme": "https",
        # "accept": "application/json, text/plain, */*",
        # "accept-encoding": "gzip, deflate, br",
        # "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
        # "cache-control": "no-cache",
        # "content-length": "157",
        # "content-type": "application/json;charset=UTF-8",
        # "cookie": "x-zp-client-id=5696d5f4-d269-4c98-8a86-499e0035dfa1; ZL_REPORT_GLOBAL={%22sou%22:{%22actionid%22:%2252f02a64-02ec-4cb6-8b13-68c3a6684464-sou%22}}; LastCity=%E5%8C%97%E4%BA%AC; LastCity%5Fid=530; acw_tc=2760823215983480865008581e0d230b2e6c7e57aa810bfc04f66486134b3c; sts_deviceid=17424f860382f0-0d863e18f6bdaa-3323766-2073600-17424f860397a4; sajssdk_2015_cross_new_user=1; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%2217424f860481d3-02aac4c998c878-3323766-2073600-17424f86049968%22%2C%22%24device_id%22%3A%2217424f860481d3-02aac4c998c878-3323766-2073600-17424f86049968%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%7D%7D; Hm_lvt_38ba284938d5eddca645bb5e02a02006=1598348092; Hm_lpvt_38ba284938d5eddca645bb5e02a02006=1598348092",
        "origin": "https://sou.zhaopin.com",
        "referer": "https://sou.zhaopin.com/?jl=530&kw=%E5%9B%BD%E7%A0%94%E5%A4%A7%E6%95%B0%E6%8D%AE%E7%A0%94%E7%A9%B6%E9%99%A2&kt=3",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36",
    }

    session.headers = headers

    response = session.post(new_url, data=payload)
    print(response)
    print(response.text)


if __name__ == '__main__':
    # pre_request()
    inner_code, meta, request_params = first_request()
    # print(inner_code)
    real_request(inner_code, meta, request_params)

